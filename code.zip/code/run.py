import builtins
builtins.unicode = str

from flask_triangle import Triangle 


from flask import Flask, send_from_directory, render_template, jsonify, make_response
from werkzeug.contrib.cache import SimpleCache
import os
import numpy as np
import networkx as nx
from networkx.readwrite import json_graph 


cache = SimpleCache()
app = Flask(__name__) 
Triangle(app) 

countries = [
  {
    "name": "WORLD",
    "population": 6916183000
  },
  {
    "name": "More developed regions",
    "population": 1240935000
  },
  {
    "name": "Less developed regions",
    "population": 5675249000
  }
]

# persons = [{"name":"Bob","age":21},{"name":"Jack","age":25},{"name":"Alice","age":22},{"name":"Alex","age":23},{"name":"Bruce","age":31},{"name":"Jim","age":12},{"name":"Adam","age":33}]

# @app.route('/static/<path:path>')
# def serve_static(path):
#     return send_from_directory('static', path)

@app.route('/js/<path:path>')
def serve_static(path):
    return send_from_directory('js', path)

@app.route('/')
def serve_index():
    return make_response(open('static/test11.html').read())
# @app.route('/')
# def home():
#     return render_template('test.html')
    # return make_response(open('../test.html').read())

# testing

#GET ALL
@app.route('/countries')
def get_countries():
    return jsonify(countries)

#GET country by id
@app.route('/countries/<cname>')
def get_country_by_cname(cname):
  return_value = {}
  for element in countries:
    if element["name"] == cname:
      return_value = {
        'name': element["name"],
        'population': element["population"]
      }
  return jsonify(return_value)


@app.route('/simple')
def simple():
    return make_response(open('../ui/static_graph.html').read())

@app.route('/graphinfo')
def graph_stats():
    G = get_graph()   
    s = 'nodes = {}, edges = {}'.format(len(G.nodes), len(G.edges))   
    return s

@app.route('/graphdata/<node_nm>')
def display_graph(node_nm):
    G = get_graph()

    # node_nm = '3'
    sub_graph = nx.ego_graph(G, node_nm, radius=1, center=True, undirected=True, distance=None)

    json = json_graph.node_link_data(sub_graph, {'link': 'edges', 'source': 'from', 'target': 'to'})
    return jsonify(json)

# functions
def get_graph():
    # load graph into cache / return graph
    
    G = cache.get('trxn_graph')
    if G is None:
        file = '../data/trxn_graph.gml'
        G = nx.read_gml(file)
        cache.set('trxn_graph', G, timeout=5 * 60)
    return G

if __name__ == '__main__':
    app.run(debug=True)