# import builtins
# builtins.unicode = str

# from flask_triangle import Triangle 

from flask import Flask, send_from_directory, render_template, jsonify, make_response

countries = [
  {
    "name": "WORLD",
    "population": 6916183000
  },
  {
    "name": "More developed regions",
    "population": 1240935000
  },
  {
    "name": "Less developed regions",
    "population": 5675249000
  }
]

app = Flask(__name__) 
# Triangle(app) 


@app.route('/')
def index():
	return make_response(open('templates/index.html').read())
    # return render_template('index.html')
    # response = make_response(render_template('index.html'))
    # return response

@app.route('/countries')
def get_countries():
    return jsonify(countries)

    
if __name__ == '__main__':
    app.run()