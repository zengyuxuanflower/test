app.controller('MainController', ['$scope', function($scope) { 
	$scope.title = 'This Month\'s Bestsellers'; 
	$scope.promo = 'The most popular books this month.';
	$scope.product = {

		name: 'The Book of Trees', 
		price: 19     
	};

	$http({
		method: "GET",
		url: "http://localhost:5000/countries",
		params: {}

	}).then(function mySuccess(response) {
  // a string, or an object, carrying the response from the server.
  $scope.myRes = response.data;
  $scope.statuscode = response.status;
  console.log($scope.myRes)      

}, function myError(response) {
	$scope.myRes = response.statusText;
});
}]);