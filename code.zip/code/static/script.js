angular.module('myApp', [])
    .controller('myCtrl', ['$scope', function($scope) {
        $scope.message = "Howdy !!";
    }]);