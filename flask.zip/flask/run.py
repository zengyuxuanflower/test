
from datetime import timedelta
from flask import Flask, request, jsonify, Blueprint, session, make_response, render_template
from flask_session import Session
from config import *
from flask_caching import Cache
from flask_cors import CORS


# def create_app(config_filename):
#     app = Flask(__name__)
#     app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

#     # app.config.from_object(config_filename)
    
#     cache = Cache(app, config={'CACHE_TYPE': 'simple'})

#     app.permanent_session_lifetime = datetime.timedelta(days=365)

    
    


#     from app import api_bp
#     app.register_blueprint(api_bp, url_prefix='')

#     # TODO - REPLACE THIS WITH JANUS GRAPH DATABASE MODEL
#     from Model import Graph
#     # db.init_app(app)
#     # graph.init_app(app)

#     return app

countries = [
  {
    "name": "WORLD",
    "population": 6916183000
  },
  {
    "name": "More developed regions",
    "population": 1240935000
  },
  {
    "name": "Less developed regions",
    "population": 5675249000
  }
]

if __name__ == "__main__":


    app = Flask(__name__)
    # CORS(app, supports_credentials=True, origins='http://0.0.0.0:8000')
    # CORS(app, supports_credentials=True, origins='http://127.0.0.1:8000')
    CORS(app, supports_credentials=True, origins='http://localhost:8000')

    app.config['SESSION_PERMANENT'] = True
    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=5)
    app.config['SESSION_FILE_THRESHOLD'] = 100  
    app.config['SECRET_KEY'] = 'config.SECRET_KEY'

    # app.config['SERVER_NAME'] = '127.0.0.1:5000'
    # app.config['SESSION_COOKIE_DOMAIN'] = '127.0.0.1:5000'

    from app import api_bp
    app.register_blueprint(api_bp, url_prefix='')

    



    sess = Session()
    sess.init_app(app)


    # @app.after_request
    # def after_request(response):

    #   # response.headers.add('Access-Control-Allow-Credentials', 'true')
    #   # response.headers.add('Access-Control-Allow-Origin', 'http://localhost:8000')


    #   response.headers.add('Access-Control-Allow-Headers',
    #     "Origin, X-Requested-With, Content-Type, Accept, x-auth")
    #   return response

    @app.after_request
    def add_cors(resp):
        """ Ensure all responses have the CORS headers. This ensures any failures are also accessible
            by the client. """
        #resp.headers['Access-Control-Allow-Origin'] = 'http://0.0.0.0:8000' # request.headers.get('Origin','*')
        #resp.headers['Access-Control-Allow-Credentials'] = 'true'
        resp.headers['Access-Control-Allow-Methods'] = 'POST, OPTIONS, GET'
        resp.headers['Access-Control-Allow-Headers'] = request.headers.get( 
            'Access-Control-Request-Headers', 'Authorization' )
        # set low for debugging
        if app.debug:
            resp.headers['Access-Control-Max-Age'] = '10'
        return resp

    @app.route('/')
    def home():
        return make_response(open('ui/index.html').read())

#GET ALL
    # @app.route('/countries')
    # def get_countries():
    #     return jsonify(countries)
        
    # special file handlers and error handlers
    @app.route('/favicon.ico')
    def favicon():
        return send_from_directory(os.path.join(app.root_path, 'static'),
                               'img/favicon.ico')


    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('404.html'), 404
        
    # app.run(host='0.0.0.0', processes=True, debug=True, port=5000)
    app.run(host='localhost', debug=True)



