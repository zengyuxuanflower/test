
from flask import Flask, request, jsonify, Blueprint, session
from flask_restful import Resource
from Model import Graph
import networkx as nx
from networkx.readwrite import json_graph

from utils import *
import json
import utils

# TODO:
# all methods using node_id_list require no spaces in list [1,2,3] works, [1,2, 3] doesnt work as ' 3' is not a valid node
# if this has an impact on the lists returned from vis.js, need to strip leading/trailing spaces
# may need to be revisited on real data

# TODO:
# input validation  - 
# e.g. if blank focal_node_id_list passed in, or if focal_node_id_list contains invalid nodes...
# maybe not necessary if API calls are linked properly to the UI - impossible to make wrong calls
# but if functionality allows free typing (instead of pure autocomplete only)..."not found" type error

class GetSessionData(Resource):

    def get(self):

        utils._init_session_focal_items()
        #_init_session_focal_items()

        return jsonify(
            session['session_node_merge_data'],
            session['focal_items'],
            session['network_view_info']
            )

class UndoRedo(Resource):

    def get(self):

        curr_undo_stack = session['undo_redo_stack']['stack']
        curr_undo_pointer = session['undo_redo_stack']['pointer']

        action = request.args.get('action', '', type=str)

        print("ACTION === ", action)

        if action.upper() == 'UNDO':
            new_undo_pointer = max(0,curr_undo_pointer - 1)
            print('undo action triggered, moving to pointer', new_undo_pointer)
        elif action.upper() == 'REDO':
            new_undo_pointer = min(len(curr_undo_stack)-1, curr_undo_pointer + 1)
            print('redo action triggered, moving to pointer', new_undo_pointer)
        else:
            new_undo_pointer = curr_undo_pointer
            print('invalid undo/redo action - staying at pointer', new_undo_pointer)

        # get the appropriate state
        new_state_g = session['undo_redo_stack']['stack'][new_undo_pointer]['graph']
        new_state_v = session['undo_redo_stack']['stack'][new_undo_pointer]['view']
        new_state_m = session['undo_redo_stack']['stack'][new_undo_pointer]['merge']
        new_state_f = session['undo_redo_stack']['stack'][new_undo_pointer]['focal']

        # set session data for merge list and pointer from appropriate state
        session['session_node_merge_data'] = new_state_m
        session['undo_redo_stack']['pointer'] = new_undo_pointer

        # send graph and view data from appropriate state
        response = generate_api_response(
            graph = new_state_g,
            network_view_info = new_state_v,
            redraw = True,
            preprocess = False,
            undoable_action = False
        )

        return response 


# TODO - REMOVE OR UPDATE THIS
class NetworkStats(Resource):

    def get(self):
        G = Graph.get_graph()

        json_data = json_graph.node_link_data(G, {'link': 'edges', 'source': 'from', 'target': 'to'})
        node_list = json_data['nodes']
        edge_list = json_data['edges']

        return({'Nodes': len(node_list), 'Edges': len(edge_list)})


# TODO - date range control
class SetDateRange(Resource):

    def get(self):
        # TODO:
        # sets date range (min and max) in session data
        # used for actions that change the view (pan, zoom) but don't change the network otherwise
        # if it results in a different network, the network is redrawn
        # TODO: maybe response should always return whether there are additional trnasactions
        #       between visible entities outside of date range selected as FYI
        #       and how many
        #       and "ranging from x date to y date"
        #   e.g. "There are 15 transactions between visible entities outside of the date range selected (xxx-xxx) between the dates of (yyy-yyy)"

        date_range_min = json.loads(request.args.get('dateRange_min'))
        date_range_max = json.loads(request.args.get('dateRange_max'))

        session['date_range_min'] = date_range_min
        session['date_range_max'] = date_range_max
        print('session date range has been set to', session['date_range_min'], session['date_range_max'])

        # TODO - refresh graph....
        return 0



class SetViewInfo(Resource):

    def get(self):

        # sets network_view_info in session data
        # used for actions that change the view (pan, zoom) but don't change the network otherwise
        # unlike other actions, this does not return a new network to the UI
        # as such, these actions are also not captured within the undo/redo stack

        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))
        session['network_view_info'] = new_network_view_info
        print('session view data has been set to', session['network_view_info'])
        return 0


# TODO - delete or update
class GetNetworkTrxnList(Resource):

    def get(self):

        curr_graph_json = session.get('session_graph')
        curr_graph = json_graph.node_link_graph(curr_graph_json)

        ct = 0
        for e in curr_graph.edges(data=True):
            ct+=e[2]['aggtrxnct']
            print(e[0], e[1], e[2]['aggtrxnct'])
        print('total trxn count:', ct)
        return 0


# TODO - delete or update
class GetNodeList(Resource):

    def get(self):

        G = Graph.get_graph()

        response = jsonify(list(G.nodes))

        return response




class GetUREList(Resource):

    # returns unique list of unresolved entities for a given set of resolved entity nodeIDs

    def get(self):

        # list of nodes on which to do action
        node_id_list = request.args.get('node_id_list', '', type=str) #.split(',')
        if node_id_list != '': 
            node_id_list = json.loads(node_id_list) # ['nodeIDList']

        node_id_list_extended = node_id_list

        # handle merged nodes
        # TODO: should really show these as a single table given entities were purposefully merged
        if 'session_node_merge_data' in session:
            session_node_merge_data = session['session_node_merge_data']

            # if merged nodes are within node_id_list, expand node_id_list with the additional UREs
            for node in node_id_list:
                print(node)
                for node_list in session_node_merge_data:
                    print(node, 'is in', node_list)
                    if node in node_list:
                        add_nodes = [n for n in node_list if n!=node]
                        node_id_list_extended = node_id_list_extended + add_nodes
               

        all_graph_data = Graph.get_graph()

        ure_dict = {}
        ure_dict_unique = {}
        for node in node_id_list_extended:

            _tmp_exploded_G = nx.ego_graph(all_graph_data, node, radius=1, center=True, undirected=True, distance=None)

            ure_dict[node] = []

            # get all entities in/out of node
            in_edges = _tmp_exploded_G.in_edges(node, data=True)
            out_edges = _tmp_exploded_G.out_edges(node, data=True)

            if len(in_edges) + len(out_edges) > 0 :
                for u,v, data in in_edges:
                    ure_dict[node].append(
                        {'nm': data['bene_nm'],
                        'addr': data['bene_addr'],
                        'acct_id': data['bene_acct_id'],
                        'bank_nm': data['bene_bank_nm'],
                        'bank_addr': data['bene_bank_addr'],
                        'bank_id': data['bene_bank_id'],
                        })
                        

                for u,v, data in out_edges:
                    ure_dict[node].append(
                        {'nm': data['orig_nm'],
                        'addr': data['orig_addr'],
                        'acct_id': data['orig_acct_id'],
                        'bank_nm': data['orig_bank_nm'],
                        'bank_addr': data['orig_bank_addr'],
                        'bank_id': data['orig_bank_id'],
                        })

        # get unique UREs only
        for key, value in ure_dict.items():
            ure_dict_unique[key] = []
            for ure in value:
                if ure not in ure_dict_unique[key]:
                    ure_dict_unique[key].append(ure)

        response = jsonify(ure_dict_unique)

        return(response)




class GetNodeListFromSearchItem(Resource):

    def get(self):

        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))
        search_str = request.args.get('search_str', '', type=str)
        search_str_type = request.args.get('search_str_type', '', type=str)

        # TODO: add search string type functionality
        # - if entity (by name, address, acct_id) --> as below
        # - if trxn ref id --> find both nodes, and then as before <-- done via indexing two nodes for each trxn
        # - ensure nodes are focal=True
        # - will need a better index? or bigger index? trxn level index?!

        print('SEARCH STRING', search_str, search_str_type)

        all_graph_data = Graph.get_graph()
        G_index = Graph.get_index()

        # load current graph from session
        curr_graph_json = session.get('session_graph')

        curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
        
        curr_node_list = list(curr_graph.nodes)

        for node_id in (curr_node_list):
            curr_graph.nodes[node_id]['fixed'] = {'x': True, 'y': True}
            curr_graph.nodes[node_id]['x'] = new_network_view_info['node_coords'][node_id]['x']
            curr_graph.nodes[node_id]['y'] = new_network_view_info['node_coords'][node_id]['y']
        G_old = nx.MultiDiGraph(curr_graph)

        print('INDEX===:', G_index[search_str])
        G_new = all_graph_data.subgraph(G_index[search_str]['re_mapping'] + curr_node_list)
        
        G = nx.compose(G_new, G_old)


        # TODO: add edge_id to re_mapping so that we can find both nodes and edge if needed
        # but does that fuck up other uses of G_index elsewhere ?

        # that way the process becomes:
        # - search for edge in UI
        # - find nodes on both sides of edge, add nodes and all transactions in between
        # - find edge_id based on search string, tag as focal=true also
        # then pass whole lot to utils

        # FOCAL ITEM_TRACKING
        utils._init_session_focal_items()

        for node in G_index[search_str]['re_mapping']:
            # if node in G.nodes():
            G.nodes[node]['focal'] = True # TODO: remove when appropriate
            # session['focal_items']['node_list'].append(node)

            utils._add_focal_item('node_list', node)

        if G_index[search_str]['type'] == 'trxn':
            # session['focal_items']['node_list'] = session['focal_items']['node_list'] + G_index[search_str]['re_mapping']
            # session['focal_items']['edge_list'] = session['focal_items']['edge_list'] + [G_index[search_str]['re_mapping']]
            # session['focal_items']['trxn_list'] = session['focal_items']['trxn_list'] + [search_str]

            utils._add_focal_item('node_list', G_index[search_str]['re_mapping'])

            ## hack to deal with self-edges:
            # if len(G_index[search_str]['re_mapping']) == 1:
            #     e = [G_index[search_str]['re_mapping'], G_index[search_str]['re_mapping']]
            # else:
            #     e = [G_index[search_str]['re_mapping']]
            # utils._add_focal_item('edge_list', e)
            utils._add_focal_item('edge_list', [G_index[search_str]['re_mapping']])

            utils._add_focal_item('trxn_list', search_str)


        # if the search type is a trxn (i.e. could use G_index[search_str]['type'] == 'trxn')
        # then the G_index[search_str]['re_mapping'] will be a list of 2 nodes
        # print('------')
        # print(tuple(G_index[search_str]['re_mapping'] + [search_str]))
        # print(G.edges)


        # x = G_index[search_str]['re_mapping'] + [search_str]
        # # if x in G.edges():
        # #     print("ADDING A TRANSACTION")

        # print(x, type(x))
        # for e in G.edges():
        #     print('EDGE===', e, type(e))


        # if G_index[search_str]['type'] == 'trxn':
        #     print("ADDING A TRANSACTION")


        response = generate_api_response(graph = G, redraw = True)

        return response




class SearchEdgeProperties(Resource):

    def get(self):

        search_str = request.args.get('search_str', '', type=str).upper()

        G = Graph.get_graph()
        G_index = Graph.get_index()

        return_keys = []
        for key, values in G_index.items():
            if search_str.upper() in key.upper():
                # print((key, values['type']))
                return_keys.append((values['type'], key))

        # response = ['[{}] {}'.format(t, k) for t, k in return_keys]
        response = [(t,k) for t, k in return_keys]

        return jsonify(response)



class GetNodeProperties(Resource):

    def get(self):

        # list of nodes on which to do action
        node_id_list = request.args.get('node_id_list', '', type=str).split(',')

        # load current graph from session
        curr_graph_json = session.get('session_graph')

        curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
        curr_node_list = list(curr_graph.nodes)

        # get full graph data
        all_graph_data = Graph.get_graph()

        response = {}
        for node in node_id_list:
            response[node] = all_graph_data.nodes[node]

        return(response)


class GetEdgeProperties(Resource):

    # TODO: TEST THIS FUNCTION

    def get(self):


        params = request.args.get('params', '', type=str)
        print(params)

        # # list of nodes on which to do action
        # edge_list = request.args.get('edge_list', '', type=str).split(',')

        # # load current graph from session
        # curr_graph_json = session.get('session_graph')

        # curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
        # curr_node_list = list(curr_graph.nodes)

        # # get full graph data
        # all_graph_data = Graph.get_graph()

        # response = {}
        # for edge in edge_list:
        #     response[edge] = all_graph_data.edges[edge]

        return(response)




# weird stuff above here



class ResetGraph(Resource):
    # returns an empty graph, clears all session data

    def get(self):

        utils._clear_session_data()

        G = nx.Graph()
        response = generate_api_response(graph = G, redraw = True)

        return(response)


class InitGraph(Resource):

    def get(self):


        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))
        
        # network_view_info = request.args.get('network_view_info', '', type=str).split(',')

        # returns graph from session, else returns empty graph
        print('x-> Initialization using graph:')
        if 'session_graph' in session:
            print('x---> Using graph from session data')
            print('x---> Using network view settings from session data', session['network_view_info'])

            # # load current graph from session
            # curr_graph_json = session.get('session_graph')
            # curr_graph = json_graph.node_link_graph(curr_graph_json) # turn session graph to networkx object

            # # json format required by vis.js
            # response = session.get('session_graph_processed') # json_graph.node_link_data(curr_graph, {'link': 'edges', 'source': 'from', 'target': 'to'})

            response = jsonify({
                    'bool_update_status': True,
                    # 'int_num_nodes': num_nodes,
                    # 'int_num_edges': num_edges,
                    # 'int_num_components': num_components,
                    'json_graph': session.get('session_graph_processed_vis'), 
                    'network_view_info': session.get('network_view_info'),
                    'focal_items': session['focal_items']
                    })

            #response = graph_to_json(curr_graph, redraw = True) # focal_node_id_list = curr_focal_node_id_list, redraw = True)

            # response = generate_api_response(graph = curr_graph, redraw = True, preprocess = False)
        else:
            print('x---> Using blank graph')

            utils._clear_session_data()

            G = nx.Graph()
            response = generate_api_response(graph = G, network_view_info = new_network_view_info, redraw = True)

        return(response)


# class GetGraph(Resource):

#     def get(self):

#         # load current graph from session
#         curr_graph_json = session.get('session_graph')
#         curr_focal_node_id_list = session.get('focal_node_id_list')
#         curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
#         curr_node_list = list(curr_graph.nodes)


#         if 'session_graph' in session:
#             curr_graph_json = session.get('session_graph')
#             response = graph_to_json(curr_graph) #, focal_node_id_list = curr_focal_node_id_list)

#         else:
#             G = nx.Graph()
#             response = graph_to_json(G)


#         return(response)


class InduceGraphWithHops(Resource):

    def get(self):

        print('x-> Inducing graph with focal_node_list & hops')

        # action = request.args.get('action', 0, type=str)
        node_id_list = request.args.get('node_id_list', '', type=str).split(',')

        hops = request.args.get('hops', 0, type=int)

        # node_list = request.args.get('node_list', '', type=str)

        # if node_list != '': 
        #     node_list = json.loads(node_list)

        # used to keep track of all nodes and their x,y coords of all nodes currently on display   
        # curr_node_pos_dict = request.args.get('curr_node_positions', '', type=str)
        # if curr_node_pos_dict != '':
        #     curr_node_pos_dict = json.loads(curr_node_pos_dict)
        #     curr_node_list = list(curr_node_pos_dict.keys())

        # used to retain current scaling and view position to pass back to client-side (to maintain view)
        # current_scale = request.args.get('curr_scale')
        # current_viewPos = request.args.get('curr_viewPos')

        all_graph_data = Graph.get_graph()

        node_list = []

        for node in node_id_list:
            # print('induce graph for node: ', node)
            node_list = node_list + list(nx.ego_graph(all_graph_data, node, radius=hops, center=True, undirected=True, distance=None).nodes)

        G = all_graph_data.subgraph(node_list)

        # TODO: remove this loop when appropriate
        for node in G.nodes():
            if node in node_id_list:
                G.nodes[node]['focal'] = True
            else:
                G.nodes[node]['focal'] = False

        session['session_node_merge_data'] = []

        # ITEM_TRACKING
        # utils._init_session_focal_items()
        utils._clear_session_data()
        # session['focal_items']['node_list'] = session['focal_items']['node_list'] + node_id_list
        utils._add_focal_item('node_list', node_id_list)




        # response = graph_to_json(G) #, node_id_list = node_id_list)
        response = generate_api_response(graph = G)

        return response


class ExpandGraph(Resource):

    # EXPAND SHOULD USE X,Y COORDS OF RESPECTIVE NODES LIKE EXPLODE CALL
    
    def get(self):

        # return a graph based on all current nodes + add n hop nodes (default = 1) from each node
        # print('x-> Expanding graph:')
        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))

        hops = request.args.get('hops', 1, type=int) # not needed, as defaults to 1

        # load current graph from session
        # curr_focal_node_id_list = session.get('focal_node_id_list')
        curr_graph_json = session.get('session_graph')
        curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
        curr_node_list = list(curr_graph.nodes)

        # get full graph data
        all_graph_data = Graph.get_graph()
        
        add_node_list = []
        # retain info on new nodes and their parents
        curr_node_x = {}
        curr_node_y = {}
        _add_node_parent_dict = {}


        for n in curr_node_list:

            # if statement is protection against UI and Session graphs becoming misaligned
            if n in new_network_view_info['node_coords']:
                curr_node_x[n] = new_network_view_info['node_coords'][n]['x']
                curr_node_y[n] = new_network_view_info['node_coords'][n]['y']

            # find and expand all nodes by 'hops'-hops
            exploded_n_G = nx.ego_graph(all_graph_data, n, radius=hops, center=True, undirected=True, distance=None)

            add_node_list += [x for x in list(exploded_n_G.nodes) if x not in list(curr_graph.nodes)]

            for add_n in add_node_list:
                if add_n not in _add_node_parent_dict:
                    _add_node_parent_dict[add_n] = n

        if len(add_node_list) == 0:
            # no additional nodes to add
            # just return same graph
            G = nx.MultiDiGraph(curr_graph)
            response = generate_api_response(graph = G, network_view_info = new_network_view_info, redraw = False, preprocess = False)
        else:
            # print('x---> Adding nodes', add_node_list)
            # induce graph from graph db containing existing nodes and nodes to be added
            # this will ensure all the required edges are retrieved also
            G_new = all_graph_data.subgraph(curr_node_list + add_node_list)

            # first fix all current nodes (better than fixing just exploable nodes?)
            for node_id in (curr_node_list):
                # if statement is protection against UI and Session graphs becoming misaligned
                if node_id in curr_graph.nodes:
                    curr_graph.nodes[node_id]['fixed'] = {'x': True, 'y': True}
                    curr_graph.nodes[node_id]['x'] = new_network_view_info['node_coords'][node_id]['x']
                    curr_graph.nodes[node_id]['y'] = new_network_view_info['node_coords'][node_id]['y']
            G_old = nx.MultiDiGraph(curr_graph)

            # set the starting coords of the new node to its parent node (the node it explodes out from)
            for node_id in (add_node_list):
                _parent_node = _add_node_parent_dict[node_id]
                G_new.nodes[node_id]['x'] = curr_node_x[_parent_node]
                G_new.nodes[node_id]['y'] = curr_node_y[_parent_node]

            G = nx.compose(G_new, G_old)
            response = generate_api_response(graph = G, network_view_info = new_network_view_info,)

        return response


class ContractGraph(Resource):

    def get(self):

        # TODO:
        # if multiple focal entities that are connected, contract will remove nodes that do not connect these two entities
        # therefore, can't contract until left with just unconnected focals
        # so, maybe should be able to move those nodes too?
        # e.g. add nodes 1, 50 (2 components), expand, expand -> 1 component, now contracting down will keep 1, 50 and connecting nodes

        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))

        # load current graph from session
        curr_graph_json = session.get('session_graph')
        # curr_focal_node_id_list = session.get('focal_node_id_list')
        curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
        curr_node_list = list(curr_graph.nodes)

        # get full graph data
        all_graph_data = Graph.get_graph()

        # get existing graph, undirected
        _tmp_G = all_graph_data.subgraph(curr_node_list)
        G = _tmp_G.to_undirected()


        # need to know focal node list as contracting nodes furthest away from these:
        focal_node_id_list = []
        for n in curr_graph_json['nodes']:
            if 'focal' in n and n['focal'] == True:
                focal_node_id_list+=[n['id']]

        # print(focal_id_list)

        # focal_node_id_list = session.get('focal_node_id_list')


        remove_nodes_list = []
        # for each focal node:
        for focal_node_id in focal_node_id_list:
            p = {} # store distance each node is from the focal entity node
            for n in G.nodes:
                try:
                    p[n] = nx.shortest_path_length(G, source=focal_node_id, target=n, weight=None)
                except (nx.exception.NetworkXNoPath, nx.exception.NodeNotFound):
                    print('no path between nodes {} & {}, skipping'.format(focal_node_id, n))

            # max_hops = max(p.values())
            # remove_nodes_list = filter(lambda x: x[1] == max_hops, p.items())
            max_hops = max(p.values())  # maximum value
            remove_nodes_list = remove_nodes_list + [k for k, v in p.items() if v == max_hops] # getting all keys containing the maximum

            #if focal_node_id in remove_nodes_list: remove_nodes_list.remove(focal_node_id)

        combined_remove_node_list = [n for n in remove_nodes_list if n not in focal_node_id_list]

        print('all nodes', G.nodes)
        print('need to remove', combined_remove_node_list)
        print('will end up with', [n for n in curr_node_list if n not in combined_remove_node_list])


        # generate new graph (based on new required nodes) and compose against old graph
        # this replaces new nodes with old nodes --> i.e. copies over existing node attributes
        G_new = all_graph_data.subgraph([n for n in curr_node_list if n not in combined_remove_node_list])
        G_old = nx.MultiDiGraph(curr_graph).subgraph([n for n in curr_node_list if n not in combined_remove_node_list])
        G = nx.compose(G_new, G_old)

        # response = graph_to_json(G) #, focal_node_id_list = curr_focal_node_id_list)
        response = generate_api_response(graph = G, network_view_info = new_network_view_info,)

        return response


class RemoveNodes(Resource):

    def get(self):

        # list of nodes on which to do action
        node_id_list = request.args.get('node_id_list')
        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))


        # load current graph from session
        curr_graph_json = session.get('session_graph')
        curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
        curr_node_list = list(curr_graph.nodes)

        # get full graph data
        all_graph_data = Graph.get_graph()

        # remove nodes from node list and focal node list if either list contains them
        new_node_id_list = [n for n in curr_node_list if n not in node_id_list]
        #new_focal_node_id_list = [n for n in curr_focal_node_id_list if n not in node_id_list]
        G_new = all_graph_data.subgraph(new_node_id_list)
        G_old = nx.MultiDiGraph(curr_graph).subgraph([n for n in curr_node_list if n not in node_id_list])
        G = nx.compose(G_new, G_old)


        # response = graph_to_json(G) #, focal_node_id_list = new_focal_node_id_list)
        response = generate_api_response(graph = G, network_view_info = new_network_view_info,)

        return response


class AddNodes(Resource):

    def get(self):

        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))

        # list of nodes on which to do action
        node_id_list = request.args.get('node_id_list', '', type=str).split(',')

        # load current graph from session
        curr_graph_json = session.get('session_graph')
        curr_graph = json_graph.node_link_graph(curr_graph_json)
        curr_node_list = list(curr_graph.nodes)

        # get full graph data
        all_graph_data = Graph.get_graph()

        add_node_list = [n for n in node_id_list if n not in curr_node_list]

        G = all_graph_data.subgraph(curr_node_list + add_node_list)

        # ITEM_TRACKING
        utils._init_session_focal_items()
        # session['focal_items']['node_list'] = session['focal_items']['node_list'] + node_id_list
        utils._add_focal_item('node_list', node_id_list)


        response = generate_api_response(graph = G, network_view_info = new_network_view_info,)

        return response



class ExplodeNodes(Resource):

    def get(self):

        # expands each node selected by 1 hop
        # node must be in current node list

        # list of nodes on which to do action
        node_id_list = request.args.get('node_id_list', '', type=str) #.split(',')
        if node_id_list != '': 
            node_id_list = json.loads(node_id_list)

        clicked_node_coords = json.loads(request.args.get('clicked_node_coords', '', type=str))
        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))

        print('ACTION: EXPLODE NODES:', node_id_list)

        # load current graph from session
        curr_graph_json = session.get('session_graph')

        curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})
        curr_node_list = list(curr_graph.nodes)

        # get full graph data
        all_graph_data = Graph.get_graph()

        _add_node_list = []

        for n in node_id_list:
            if n in curr_node_list:
                exploded_node_subgraph = nx.ego_graph(all_graph_data, n, radius=1, center=True, undirected=True, distance=None)
                _add_node_list += list(exploded_node_subgraph.nodes)
            else:
                print('error: node to explode', n, ' is not in current node list - so cant explode')

        add_node_list = [n for n in _add_node_list if n not in curr_node_list]
        print('ADDING THESE NODES', add_node_list)

        if len(add_node_list) == 0:

            G = nx.MultiDiGraph(curr_graph)
            response = generate_api_response(graph = G, network_view_info = new_network_view_info, redraw = False, preprocess = False)

        else:

            # induce graph from graph db containing existing nodes and nodes to be added
            # this will ensure all the required edges are retrieved also
            G_new = all_graph_data.subgraph(curr_node_list + add_node_list)

            # induce graph from existing nodes (which includes existing node data)
            # first fix the node(s) being exploded
            # TODO: now set to fix all nodes before explode...what's the best UX here?
            for node_id in (curr_node_list):
                curr_graph.nodes[node_id]['fixed'] = {'x': True, 'y': True}
                curr_graph.nodes[node_id]['x'] = new_network_view_info['node_coords'][node_id]['x']
                curr_graph.nodes[node_id]['y'] = new_network_view_info['node_coords'][node_id]['y']

            for node_id in (add_node_list):
                G_new.nodes[node_id]['x'] = clicked_node_coords['x']
                G_new.nodes[node_id]['y'] = clicked_node_coords['y']

            G_old = nx.MultiDiGraph(curr_graph)

            # compose graphs - this replaces nodes in G_new with nodes from G_old where conflict
            # G_old nodes contain existing node properties
            G = nx.compose(G_new, G_old)

            # response = graph_to_json(G) #, focal_node_id_list = curr_focal_node_id_list)
            response = generate_api_response(graph = G, network_view_info = new_network_view_info)

        return response


class MergeNodes(Resource):
    # on the fly combine multiple nodes into one

    def get(self):

        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))
        node_id_list = request.args.get('node_id_list', '', type=str)
        if node_id_list != '': 
            node_id_list = json.loads(node_id_list)

        # load current graph from session
        curr_graph_json = session.get('session_graph')

        curr_graph = json_graph.node_link_graph(curr_graph_json)
        curr_node_list = list(curr_graph.nodes)
        G = nx.MultiDiGraph(curr_graph)

        if len(node_id_list) >= 2:
            if 'session_node_merge_data' in session:
                # load current node combinations...
                curr_node_merge_data = session.get('session_node_merge_data')
            else:
                curr_node_merge_data = []

            print ('old merging list', curr_node_merge_data, type(curr_node_merge_data))
            new_node_merge_data = curr_node_merge_data + [node_id_list]
            session['session_node_merge_data'] = new_node_merge_data

            print ('new merging list', new_node_merge_data)
        else:
            print('must select 2 or more nodes to merge')

        response = generate_api_response(graph = G, network_view_info = new_network_view_info, preprocess=False)

        return response


class UnmergeNodes(Resource):
    # unmerge nodes
    # TODO : does not work 
    # this function removes to merged list from the session data, but networkx will not be able to split nodes up again
    # to fix this - for each merge action, must retain some unmerge component data for the entities in question
    # then fit this data back into the graph! complex!!
    # if vis.js merged on the fly, would be so much easier...?

    def get(self):

        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))
        node_id_list = request.args.get('node_id_list', '', type=str)
        if node_id_list != '': 
            node_id_list = json.loads(node_id_list)

        # load current graph from session
        curr_graph_json = session.get('session_graph')

        curr_graph = json_graph.node_link_graph(curr_graph_json)
        curr_node_list = list(curr_graph.nodes)
        G = nx.MultiDiGraph(curr_graph)

        if len(node_id_list) >= 1:
            if 'session_node_merge_data' in session:
                # load current node combinations...
                curr_node_merge_data = session.get('session_node_merge_data')
                new_node_merge_data = []
                for node in node_id_list:
                    for node_list in curr_node_merge_data:
                        if node in node_list:
                            print('dropping merge list', node_list)
                        else:
                            new_node_merge_data = new_node_merge_data + node_list

            else:
                print('no merged nodes at all')

            print('OLD LIST', session['session_node_merge_data'] )
            session['session_node_merge_data'] = new_node_merge_data
            print('NEW LIST', session['session_node_merge_data'] )

        response = generate_api_response(graph = G, network_view_info = new_network_view_info, preprocess=False)

        return response




class SetNodeFix(Resource):
    # called whenever nodes are fixed or unfixed
    # sets the 'fixed', 'x', 'y' node properties

    # TODO: GET NODE LIST INSTEAD OF SINGLE NODES VIA LOOP IN UI
    # - need UI to send all nodes as lists (even single node)

    def get(self):

        # node_id = request.args.get('node_id', '', type=str)
        node_id_list = request.args.get('node_id_list', '', type=str)
        print('IS THIS POPULATED?', node_id_list)
        if node_id_list != '': 
            node_id_list = json.loads(node_id_list)

        to_fix = request.args.get('to_fix', '', type=str)
        new_network_view_info = json.loads(request.args.get('network_view_info', '', type=str))


        print('setNodeFix called on list:', node_id_list)
        # load current graph from session
        curr_graph_json = session.get('session_graph')
        curr_graph = json_graph.node_link_graph(curr_graph_json) #, {'edges': 'links', 'source': 'from', 'target': 'to'})

        for node_id in node_id_list:
            if to_fix == 'true':
                print("fixing:", node_id)
                curr_graph.nodes[node_id]['fixed'] = {'x': True, 'y': True}
                curr_graph.nodes[node_id]['x'] = new_network_view_info['node_coords'][node_id]['x']
                curr_graph.nodes[node_id]['y'] = new_network_view_info['node_coords'][node_id]['y']
            else:
                print("unfixing:", node_id)
                curr_graph.nodes[node_id]['fixed'] = {'x': False, 'y': False}

        response = generate_api_response(graph = curr_graph, network_view_info = new_network_view_info, redraw = False, preprocess = False)

        return response

