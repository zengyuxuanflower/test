

import networkx as nx
from networkx.readwrite import json_graph
from flask import Flask, request, jsonify, Blueprint, session
from Model import Graph

import community





# TODO:
# split into multiple methods 
# - for checking session data / setting session data
# - for aggregatin trxn edges
# - for x,y coord positioning of nodes
# allows api methods to call these utils functions separately if needed



# def _lightenDarkenColor(hex_col, amt):

#     usePound = False;
  
#     if (hex_col[0] == "#"):
#         hex_col = hex_col[1:];
#         useHash = True;
 
#     num = parseInt(hex_col,16);
 
#     var r = (num >> 16) + amt;
 
#     if (r > 255) r = 255;
#     else if  (r < 0) r = 0;
 
#     var b = ((num >> 8) & 0x00FF) + amt;
 
#     if (b > 255) b = 255;
#     else if  (b < 0) b = 0;
 
#     var g = (num & 0x0000FF) + amt;
 
#     if (g > 255) g = 255;
#     else if (g < 0) g = 0;
 
#     return (useHash?"#":"") + (g | (b << 8) | (r << 16)).toString(16);


# def _get_existing_graph():

#     curr_nx_graph_json = session.get('graph_json')
#     curr_nx_graph = json_graph.node_link_graph(curr_nx_graph_json)

#     return curr_nx_graph


def _clear_session_data():
    session.clear()
    session['session_node_merge_data'] = []
    session['focal_items'] = {}
    session['focal_items']['node_list'] = []
    session['focal_items']['edge_list'] = []
    session['focal_items']['trxn_list'] = []
    session['focal_items']['full_list'] = []


def _init_session_focal_items():
    if 'focal_items' in session:
        pass
    else:
        session['focal_items'] = {}
        session['focal_items']['node_list'] = []
        session['focal_items']['edge_list'] = []
        session['focal_items']['trxn_list'] = []
        session['focal_items']['full_list'] = []


def _add_focal_item(focal_list, focal_item):
    # checks if focal item is in session list, if not, it adds it

    if type(focal_item) != list:
        focal_item = [focal_item]

    for i in focal_item:
        # if i in session['focal_items'][focal_list]:
        #     print('focal item', i, 'already in list', focal_list)
        # else:
        if i not in session['focal_items'][focal_list]:
            session['focal_items'][focal_list].append(i)

        if i not in session['focal_items']['full_list']:
            session['focal_items']['full_list'].append(i)



def _merge_nodes(G):
    # TODO: need to retain unmerged graph so that is stored in session later...

    if 'session_node_merge_data' in session:
        session_node_merge_data = session['session_node_merge_data']
    else:
        session_node_merge_data = []

    for merge_list in session_node_merge_data:

        into_node = merge_list[0]

        if 'merged_ct' not in G.nodes[into_node]:
            G.nodes[into_node]['merged_ct'] = 1

        for put_node in merge_list[1:]:

            if into_node in G.nodes and put_node in G.nodes:
                print(into_node, '<-', put_node )
                G = nx.contracted_nodes(G, into_node, put_node)

                G.nodes[into_node]['merged_ct']+= 1 # for glyphs, TODO: fix counter

    # TODO - by definition merged nodes are "explodable" because one of their connecting nodes
    # is not longer on display (i.e. its a 'put_node' and gone into the 'into_node')
    # so the glyphs finder needs to change the glyph to show "merged" type node instead

    return G



def _community_detection(G):
    # detect and set community colors
    # TODO: if graph unchanged, dont run community detection?
    # TODO: try and keep existing community colors
    # - if a set of nodes = color x
    # - after refresh, those nodes = color 6
    # - switch colors for that whole community to x
    # - if any other community had x then swap with y
    # TODO: other community detection algos - networkx.algorithms.community module
    # TODO: use count instead of amount

    solarized = [
    '#b58900','#cb4b16','#dc322f','#d33682',
    '#6c71c4','#268bd2','#2aa198','#859900']


    flattened = [
    '#ED4C67','#F79F1F','#A3CB38','#1289A7',
    '#D980FA','#B53471','#EE5A24','#009432',
    '#0652DD','#9980FA','#833471','#EA2027',
    '#006266','#1B1464','#5758BB','#6F1E51',
    '#FFC312','#C4E538','#12CBC4','#FDA7DF']

    color_list = flattened 

    tmp_G = G.to_undirected()

    partition = community.best_partition(tmp_G)
    # print('COMMUNITY SET:' , set(partition.values()))
    # print('COMMUNITY DICT:' , partition)

    for key, value in partition.items():
        c = value # community
        G.node[str(key)]['format_community'] = c

        color_index = c%len(color_list) # take mod to repeat colors if needed
        G.node[str(key)]['theme_community_color'] = {
            'border': color_list[color_index],
            'background': 'rgba(161, 161, 180, 0.4)',
            'highlight': {
                'border': color_list[color_index],
                'background': color_list[color_index], #color_list[color_index]
                }
            }
        G.node[str(key)]['theme_community_shadow'] = {'enabled': True, 'color': color_list[color_index], 'x':0,'y':0, 'size':20}

    return G

# def _aggregate_edges(G):

#     # TODO: TURN THIS INTO A SINGLE LOOP ...
#     # TODO: somehow only loop/aggregate edges that don't exist
#     #  - compare old vs new graph, get new node-node pairs
#     #    aggregate them, merge graphs...
#     # OR have a graph thats a mixture of aggregated edges and unaggregated
#     #    edges and sum only IF unaggregated edges (>1 per pair...)
#     #    requires storing/loading the aggregated graph in session instead

#     # create new graph from G
#     # this will retain node properties, but edges will be aggregated/replaced
#     # aggregate_G = nx.MultiDiGraph(G)

#     # aggregate multiple transaction edges between entities into single edge
#     agg_edge_dict = {}

#     # {
#     #     (a,b): {'trxn_list': [{'trxn_ref_id': 'abc1-a-b', 'trxn_amt': 1000 .... }, {'trxn_ref_id': 'abc2-a-b', 'trxn_amt': 1000 .... } ]},
#     #     (b,c): {'trxn_list': [{'trxn_ref_id': 'abc3-a-b', 'trxn_amt': 1000 .... }, {'trxn_ref_id': 'abc2-a-b', 'trxn_amt': 1000 .... } ]},
#     #     ...
#     # }
   
#     # first iterate through edges and create a dictionary of aggregate edge data
#     # delete edge after iteration
#     # TODO: aggregate amt needs currency conversion
#     # TODO: parameterize using config file to identifiy trxn_amt variable to sum

#     aggregate_G = nx.MultiDiGraph()
#     aggregate_G.add_nodes_from(G.nodes(data = True))


#     for edge in G.edges:

#         node_from = edge[0]
#         node_to = edge[1]

#         data = G.get_edge_data(*edge)

#         if 'trxndata' in data:
#             # if the edge is already aggregated edge
#             trxn_list = data['trxndata']['trxn_list']
#         else:
#             # if the edge is a single trxn edge
#             # TODO: generalise for using all edge attributes...
#             # TODO: adapt to use config
#             _trxn_ref_id = edge[2] 
#             _trxn_amt = data['orig_trxn_amt']
#             # _trxn_orig_nm = data['orig_nm']
#             # _trxn_bene_nm = data['bene_nm']
#             # _tmp_trxn_dict = {'trxn_ref_id': _trxn_ref_id, 'trxn_amt': _trxn_amt, 'orig_nm': _trxn_orig_nm, 'bene_nm': _trxn_bene_nm} #TODO: add dt and all other properties
#             _tmp_trxn_dict = data

#             trxn_list = [_tmp_trxn_dict]


#         try:
#             curr_trxn_list = agg_edge_dict[(node_from,node_to)]['trxn_list']

#             if trxn_list!=curr_trxn_list:
#                 curr_agg_trxn_amt = agg_edge_dict[(node_from,node_to)]['agg_trxn_amt']
#                 curr_agg_trxn_ct = agg_edge_dict[(node_from,node_to)]['agg_trxn_ct']

#                 # print('CURR TRXN LIST: ',node_from,node_to, type(curr_trxn_list), x)
#                 agg_edge_dict[(node_from,node_to)]['trxn_list'] = curr_trxn_list + trxn_list #.append(trxn_list)
#                 agg_edge_dict[(node_from,node_to)]['agg_trxn_amt'] = curr_agg_trxn_amt + _trxn_amt
#                 agg_edge_dict[(node_from,node_to)]['agg_trxn_ct'] = curr_agg_trxn_ct + 1

#         except KeyError:

#             # else add a new key
#             agg_edge_dict[(node_from,node_to)] = {'trxn_list': trxn_list, 'agg_trxn_amt': _trxn_amt, 'agg_trxn_ct': 1}


#     # use agg_edge_dict to add aggregated data edges to node-only graph
#     for key, trxn_dict in agg_edge_dict.items():

#         node_from = key[0]
#         node_to = key[1]

#         agg_trxn_amt = trxn_dict['agg_trxn_amt']
#         agg_trxn_ct = trxn_dict['agg_trxn_ct']
#         trxn_list = trxn_dict['trxn_list']

#         aggregate_G.add_edge(node_from, node_to,
#             aggtrxnamt = agg_trxn_amt,
#             aggtrxnct = agg_trxn_ct,
#             value = agg_trxn_amt, trxndata = trxn_dict) # TODO: put this back in after debugging

#     return aggregate_G



def _aggregate_edges(G):

    # TODO: TURN THIS INTO A SINGLE LOOP ...
    # TODO: somehow only loop/aggregate edges that don't exist
    #  - compare old vs new graph, get new node-node pairs
    #    aggregate them, merge graphs...
    # OR have a graph thats a mixture of aggregated edges and unaggregated
    #    edges and sum only IF unaggregated edges (>1 per pair...)
    #    requires storing/loading the aggregated graph in session instead

    # create new graph from G
    # this will retain node properties, but edges will be aggregated/replaced
    # aggregate_G = nx.MultiDiGraph(G)

    # aggregate multiple transaction edges between entities into single edge
    agg_edge_dict = {}

    # {
    #     (a,b): {'trxn_list': [{'trxn_ref_id': 'abc1-a-b', 'trxn_amt': 1000 .... }, {'trxn_ref_id': 'abc2-a-b', 'trxn_amt': 1000 .... } ]},
    #     (b,c): {'trxn_list': [{'trxn_ref_id': 'abc3-a-b', 'trxn_amt': 1000 .... }, {'trxn_ref_id': 'abc2-a-b', 'trxn_amt': 1000 .... } ]},
    #     ...
    # }
   
    # first iterate through edges and create a dictionary of aggregate edge data
    # delete edge after iteration
    # TODO: aggregate amt needs currency conversion
    # TODO: parameterize using config file to identifiy trxn_amt variable to sum

    aggregate_G = nx.MultiDiGraph()
    aggregate_G.add_nodes_from(G.nodes(data = True))


    for edge in G.edges:

        node_from = edge[0]
        node_to = edge[1]

        data = G.get_edge_data(*edge)

        if 'trxnData' in data:
            # if the edge is already aggregated edge
            trxn_list = data['trxnData']['trxn_list']
        else:
            # if the edge is a single trxn edge
            # TODO: generalise for using all edge attributes...
            # TODO: adapt to use config
            _trxn_ref_id = edge[2]


            # use base transaction amount (normalized to USD) for aggregating edge value
            _base_trxn_amt = data['base_trxn_amt']
            _base_curr_cd = data['base_curr_cd']

            # need to keep origal currency to correctly groupby into currency group edges
            _orig_trxn_amt = data['orig_trxn_amt'] # probably not used
            _orig_curr_cd = data['orig_curr_cd']

            _tmp_trxn_dict = data # this could be a generalized dict based on config e.g. {'trxn_ref_id': _trxn_ref_id, 'trxn_amt': _trxn_amt, 'orig_nm': _trxn_orig_nm, 'bene_nm': _trxn_bene_nm}
            trxn_list = [_tmp_trxn_dict]


        try:
            curr_trxn_list = agg_edge_dict[(node_from,node_to)]['trxn_list']

            if trxn_list!=curr_trxn_list:
                curr_agg_trxn_amt = agg_edge_dict[(node_from,node_to)]['agg_base_trxn_amt']
                curr_agg_trxn_ct = agg_edge_dict[(node_from,node_to)]['agg_trxn_ct']

                # print('CURR TRXN LIST: ',node_from,node_to, type(curr_trxn_list), x)
                agg_edge_dict[(node_from,node_to)]['trxn_list'] = curr_trxn_list + trxn_list #.append(trxn_list)
                agg_edge_dict[(node_from,node_to)]['agg_base_trxn_amt'] = curr_agg_trxn_amt + _base_trxn_amt
                agg_edge_dict[(node_from,node_to)]['agg_trxn_ct'] = curr_agg_trxn_ct + 1

        except KeyError:

            # else add a new key
            agg_edge_dict[(node_from,node_to)] = {'trxn_list': trxn_list, 'agg_base_trxn_amt': _base_trxn_amt, 'agg_trxn_ct': 1}


    # use agg_edge_dict to add aggregated data edges to node-only graph
    for key, trxn_dict in agg_edge_dict.items():

        node_from = key[0]
        node_to = key[1]

        agg_base_trxn_amt = trxn_dict['agg_base_trxn_amt']
        agg_trxn_ct = trxn_dict['agg_trxn_ct']

        aggregate_G.add_edge(
            node_from,
            node_to,
            curr_cd = 'all',
            aggBaseTrxnAmt = agg_base_trxn_amt,
            aggTrxnCt = agg_trxn_ct,
            value = agg_base_trxn_amt,
            trxnData = trxn_dict
        )

        # for each aggregated edge, add separate edges grouped by each currency
        curr_cd_set = set([trxn['orig_curr_cd'] for trxn in trxn_dict['trxn_list']])
        trxn_by_curr_dict = {}
        for curr_cd in curr_cd_set:
            # create list of transactions for curr_cd
            trxn_by_curr_dict[curr_cd] = [trxn for trxn in trxn_dict['trxn_list'] if trxn['orig_curr_cd'] == curr_cd]

            # create aggregates
            curr_agg_base_trxn_amt = sum([_trxn_dict['base_trxn_amt'] for _trxn_dict in trxn_by_curr_dict[curr_cd]])
            curr_agg_trxn_ct = len(trxn_by_curr_dict[curr_cd])
            trxn_dict = {'trxn_list': trxn_by_curr_dict[curr_cd], 'agg_base_trxn_amt': curr_agg_base_trxn_amt, 'agg_trxn_ct': curr_agg_trxn_ct}
            
            # TODO: this will create a multi-di-graph
            # vis.js has issues with arrows for this type of graph
            # add edge for currency
            aggregate_G.add_edge(
                node_from,
                node_to,
                curr_cd = curr_cd,
                aggBaseTrxnAmt = curr_agg_base_trxn_amt,
                aggTrxnCt = curr_agg_trxn_ct,
                value = curr_agg_base_trxn_amt,
                trxnData = trxn_dict
            )

    return aggregate_G


def _nodeCanExplode(G, node_id):
    
    # load current graph from session
    curr_graph = G
    curr_node_list = list(curr_graph.nodes)

    # get full graph data
    all_graph_data = Graph.get_graph()

    _add_node_list = []

    if node_id in curr_node_list:
        exploded_node_subgraph = nx.ego_graph(all_graph_data, node_id, radius=1, center=True, undirected=True, distance=None)
        _add_node_list += list(exploded_node_subgraph.nodes)

    add_node_list = [n for n in _add_node_list if n not in curr_node_list]

    return (len(add_node_list))


def _get_node_features(node_id):
    # load the nodes features into the graph from the feature table
    # TODO: this will need to be a SQL query

    node_feature_index = Graph.get_feature_index()

    return node_feature_index[node_id]



def _process_nodes(G):
    # post-processing for nodes
    # - sets label to the 'name' property <-- update to use better name
    # - calculates value based on sum of transaction in and out
    # - adds additional node properties from feature table

    for node in G.nodes():

        G.node[node]['expandable_ct'] = _nodeCanExplode(G, node)
        G.node[node]['feature_list'] = _get_node_features(node) 

        # find name of node as most common name from edges
        # TODO: treat merged nodes differently - result in list of names & merged icon
        nm_list = []
        in_edges = G.in_edges(node)
        out_edges = G.out_edges(node)

        # get most common name from in- and out-edges for aggregated graph
        # TODO: bug - if no edges on graph (just a single node) <-- need a look-up on whole graph!!
        if len(in_edges) + len(out_edges) > 0 :
            for edge in in_edges:
                e = G[edge[0]][edge[1]]
                trxn_list = e[0]['trxnData']['trxn_list'] # dict of transactions contained in aggregated edge
                for trxn in trxn_list:
                    nm_list.append(trxn['bene_nm'])

            for edge in out_edges:
                e = G[edge[0]][edge[1]]
                trxn_list = e[0]['trxnData']['trxn_list'] # dict of transactions contained in aggregated edge
                for trxn in trxn_list:
                    nm_list.append(trxn['orig_nm'])

            re_id = G.node[node]['name'] # resolved entity id
            most_common_name = max(set(nm_list), key=nm_list.count)
            num_trxn = len(nm_list) # number of transactions
            # TODO: if we want number of ure for each re then concat nm,addr,acct_id,bank and find length of set?

            node_name = '{}'.format(most_common_name)


        else:
            # if no edges available...

            re_id = G.node[node]['name'] # resolved entity id

            all_graph_data = Graph.get_graph()
            _tmp_G = nx.ego_graph(all_graph_data, re_id, radius=1, center=True, undirected=True, distance=None)

            in_edges = _tmp_G.in_edges(node, data=True)
            out_edges = _tmp_G.out_edges(node, data=True)

            if len(in_edges) + len(out_edges) > 0 :
                for u,v, data in in_edges:
                    nm_list.append(data['bene_nm'])

                for u,v, data in out_edges:
                    nm_list.append(data['orig_nm'])

                re_id = _tmp_G.node[node]['name'] # resolved entity id
                most_common_name = max(set(nm_list), key=nm_list.count)
                node_name = '{}'.format(most_common_name)

        G.node[node]['label'] = node_name 

        val = 0
        for e in G.in_edges(node):
            val = val + G.get_edge_data(*e)[0]['aggBaseTrxnAmt']
        for e in G.out_edges(node):
            val = val + G.get_edge_data(*e)[0]['aggBaseTrxnAmt']
        G.node[node]['value'] = val

    return G




def _preprocess_graph(G, a, b, c):

    G = _merge_nodes(G)
    if a: G = _aggregate_edges(G)
    if b: G = _process_nodes(G)
    if c: G = _community_detection(G)  #TODO: this only needs to occur if graph changed

    for node in G.nodes():

        # G.node[node]['community_color'] = G.node[node]['color']

        if ('focal' in G.node[node]) and G.node[node]['focal']:
            # G.node[node]['shape'] = 'circle'
            pass

        elif int(G.node[node]['expandable_ct']) > 0:
            # G.node[node]['shape'] = 'square'
            pass

        else:
            G.node[node]['shape'] = 'dot'


    return G

# # NOTES:
# # SESSION DATA ALWAYS STORES RAW GRAPH - NOT GRAPH AGGREGATED EDGES ETC
# # ALWAYS NEED TO THEN RE-PROCESS GRAPH
# # - AGGREGATE EDGES
# # - MERGE ANY DYNAMICALLY MERGED NODES..
# # - ... ?

def generate_api_response(**kwargs):


    # if api request sends graph (typically it is), get it
    if 'graph' in kwargs:
        new_G = kwargs['graph']
        new_G_sent = ('graph' in kwargs)

    # if a graph exists in session data, get it
    if 'session_graph' in session:
        session_G = session['session_graph']

    # if api request sends network_view_info, get it
    if 'network_view_info' in kwargs:
        new_network_view_info = kwargs['network_view_info']
    elif 'network_view_info' in session:
        new_network_view_info =  session['network_view_info']
    else:
        new_network_view_info = {}

    # if network_view_info exists in session data, get it
    # if 'network_view_info' in session:
    #     session_network_view_info = session['network_view_info']
    #     print('SESSION VIEW INFO HAS: ', session_network_view_info)

    if 'preprocess' in kwargs:
        preprocess = kwargs['preprocess']
    else:
        preprocess = True

    if 'undoable_action' in kwargs:
        undoable_action = kwargs['preprocess']
    else:
        undoable_action = True      



    change = True
    # if new graph was sent...
    # TODO: does it do all of this even for fixing a node?!
    if new_G_sent:

        # pre-process graph:
        # - individual transaction edges to single edges with properties
        # - adding value to node for sizing
        # - community detection and colorize accordingly
        # (its the pre-processed graph that needs to be stored in session so always pre-process)
        # TODO: could add complex logic to not re-create whole graph
        #  - check for what is different (nodes, edges etc) and pre-process just that
        #  - quite a lot of possible difference may not optimize...

        aggregate_edges = True
        calculate_node_sizes = True
        community_detection = True

        if preprocess == False:
            aggregate_edges = False

        new_G_processed = _preprocess_graph(new_G, aggregate_edges, calculate_node_sizes, community_detection)
        new_G_processed_json = json_graph.node_link_data(new_G_processed)
            

        if 'session_graph' not in session:
            print('no graph in session so init session with new graph')

            session['session_graph'] = new_G_processed_json
            session['network_view_info'] = new_network_view_info
            #print('!! SAVING NETWORK VIEW INFO TO SESSION:', new_network_view_info)

            # boolean to tell ui to refresh/draw graph
            redraw_ui_graph = True 

        elif new_G_processed_json == session['session_graph']:

            new_network_view_info = session['network_view_info']

            print('graph unchanged')
            #print('!! LOADING network view info from session:', new_network_view_info)

            # boolean to tell ui to refresh/draw graph
            redraw_ui_graph = False 

            change = False

        else:
            print('graph changed')

            session['session_graph'] = new_G_processed_json
            session['network_view_info'] = new_network_view_info
            #print('!! SAVING NETWORK VIEW INFO TO SESSION:', new_network_view_info)

            redraw_ui_graph = True 


        # session['session_graph'] = new_G_processed_json
        # session['network_view_info'] = new_network_view_info

        # json format required by vis.js
        new_G_processed_json_vis = json_graph.node_link_data(new_G_processed, {'link': 'edges', 'source': 'from', 'target': 'to'})
        session['session_graph_processed_vis'] = new_G_processed_json_vis

    if 'redraw' in kwargs:
        redraw_ui_graph = kwargs['redraw']


    if undoable_action:

        # print('ADDING UNDO DATA')
        # if 'undo_stack' in session:
        #     print('UNDO STACK FOUND IN SESSION')
        #     session['undo_stack'].append([new_G_processed, session['network_view_info'], session['session_node_merge_data']])
        # else:
        #     print('CREATING NEW UNDO STACK')
        #     session['undo_stack'] = [[new_G_processed, session['network_view_info'], session['session_node_merge_data']]]

        # if 'redo_stack' not in session:
        #     session['redo_stack'] = []

        # print('UNDO:', '##############################################'[:len(session['undo_stack'])] , len(session['undo_stack']))
        # print('REDO:', '##############################################'[len(session['redo_stack'])] , len(session['redo_stack']))

        if 'undo_redo_stack' in session:
            print('ADDING UNDO DATA')

            # delete everything in stack after current pointer - this is in case there have been redo actions prior to this action
            session['undo_redo_stack']['pointer'] += 1

            curr_pointer = session['undo_redo_stack']['pointer']
            curr_stack = session['undo_redo_stack']['stack']
            session['undo_redo_stack']['stack'] = curr_stack[0:curr_pointer]

            session['undo_redo_stack']['stack'].append({
                'graph': new_G_processed,
                'view': session['network_view_info'],
                'merge': session['session_node_merge_data'],
                'focal': session['focal_items']
                }
            )
            
        else:
            print('CREATING NEW UNDO STACK')
            session['undo_redo_stack'] = {
                'stack': [{
                    'graph': new_G_processed,
                    'view': session['network_view_info'],
                    'merge': session['session_node_merge_data'],
                    'focal': session['focal_items']
                    }],
                'pointer': 0
            }

    undo_string = '##############################################'[:len(session['undo_redo_stack']['stack'])]
    p = session['undo_redo_stack']['pointer']
    undo_string = undo_string[:p] + 'x' + undo_string[p+1:]

    # print('UNDO:', undo_string , len(session['undo_redo_stack']['stack']), session['undo_redo_stack']['pointer'])
    # print('MERGE DATA:', session['undo_redo_stack']['stack'][p]['merge'])
 
    return jsonify({
        'bool_update_status': redraw_ui_graph,
        'json_graph': new_G_processed_json_vis, 
        'network_view_info': new_network_view_info,
        'focal_items': session['focal_items']
    })



    # if new_G_sent:

    #     # pre-process graph:
    #     # - individual transaction edges to single edges with properties
    #     # - adding value to node for sizing
    #     # - community detection and colorize accordingly
    #     # (its the pre-processed graph that needs to be stored in session so always pre-process)
        

    #     if 'session_graph' not in session:
    #         print('no graph in session so init session with new graph')

    #         # do all pre-processing and store in session
    #         new_G_processed = _preprocess_graph(new_G, True, True, True)

    #         session['session_graph'] = new_G_processed_json
    #         session['network_view_info'] = new_network_view_info

    #         # boolean to tell ui to refresh/draw graph
    #         refresh_ui_graph = True 

    #     else:

    #         # graph in session - so need to compare and pre-process accordingly

    #         # if additional nodes 
    #             # (0) get new nodes
    #             # (1) get edges for new-new and existing-new node pairs
    #             # (2) pre-process edges
    #             # (3) combine session_G with additionals from new_G

    #         # if additional edges (if date changed, could just result in new edge between existing nodes)
    #             # (1) pre-process edges
    #             # (2) add new edge to G

    #         # if existing edges have additional transaction data (due to date change...)
    #             # (1) get existing edges
    #             # (2) get new edges
    #             # (3) aggregate edges - agg edge + new single trxn edge

    #         # if less nodes?
    #         # if less edges?
    #         # if need to remove transaction(s) from existing edges... ?

    #         # else graph is the same?
    #             # (0) - ensure this is always the same
    #             # (1) - do nothing...



    #      new_G_processed_json == session['session_graph']:

    #         new_network_view_info = session['network_view_info']
    #         print('graph unchanged')

    #         # boolean to tell ui to refresh/draw graph
    #         refresh_ui_graph = False 

    #     else:
    #         print('graph changed')

    #         session['session_graph'] = new_G_processed_json
    #         session['network_view_info'] = new_network_view_info

    #         refresh_ui_graph = True 




def graph_to_json(G, **kwargs):

    """

    Check G against session data, return aggregated transactions as edges

    If no graph in user session, the graph is added to the session. 
    
    If G differs to the graph in session, graph in session is updated.

    If G is identical the graph (based on having the same nodes, edges)
    as the graph in the session, returns a bool to UI to not refresh the
    network.

    Always returns a json containing the graph as json along with additonal
    information about the graph. This is directly sent to the client-side UI.

    Note: - The returned graph contains aggregated edges and has keys required
            by vis.js
          - The graph stored in session data is the original networkx object

    :params:
        G: networkx graph generated by user UI action
        **kwargs:
            focal_node_id_list: list of focal entities if needed by particular API call
            redraw: bool if true then forces redraw even if returned network doesnt change

    :return:
        response: jsonified description of returned graph and json graph itself

    """

    # create json format to store in session
    # not sure if this is needed - could maybe store 'G' in session? 
    

    # if api call has modified the focal_node_id_list, use it, else read from session
    # if 'focal_node_id_list' in kwargs:
    #     focal_node_id_list = kwargs['focal_node_id_list']
    # elif 'focal_node_id_list' in session:
    #     focal_node_id_list =  session['focal_node_id_list']
    # else:
    #     focal_node_id_list = []

    # if network_view_info has been passed from front-end this is the latest view
    # else take the view from session
    if 'network_view_info' in kwargs:
        network_view_info = kwargs['network_view_info']
    elif 'network_view_info' in session:
        network_view_info =  session['network_view_info']
    else:
        network_view_info = [] 

    
    graph_as_json = json_graph.node_link_data(G)
    # preprocessed_G = _preprocess_graph(G)

    # graph_as_json = json_graph.node_link_data(preprocessed_G)

    # check if there is an existing graph in the session
    # if no graph, add graph and set graph_changed=True so UI refreshes
    # if same graph, set graph=changed=True so UI does not move
    # if different graph, update the graph and set graph_changed=True so UI refreshes.



    if 'graph_json' not in session: #not session['graph_json']:
        
        graph_changed = True
        session['graph_json'] = graph_as_json

        print('')
        print('\n--- NEW GRAPH - GRAPH TO SEND ---')
        print(graph_as_json['nodes'])
        print('\n')

    elif graph_as_json == session['graph_json']:

        graph_changed = False

        print('')
        print('\n--- GRAPH UNCHANGED - GRAPH TO SEND ---')
        print(graph_as_json['nodes'])
        print('\n')

    else:

        graph_changed = True

        # make copy of old graph before updating session (just for prints below)
        old_graph = session['graph_json']
        session['graph_json'] = graph_as_json
    
        print('')
        print('\n--- GRAPH CHANGED - OLD GRAPH ---')
        # print(old_graph['nodes'])
        for n in old_graph['nodes']:
            print(n)

        print('\n--- GRAPH CHANGED - NEW GRAPH TO SEND ---')
        # print(graph_as_json['nodes'])
        for n in graph_as_json['nodes']:
            print(n)

        print('\n')
        print('')



    preprocessed_G = _preprocess_graph(G,1,1,~graph_changed)


    # TODO: separate aggregate edges into parameterized function
    # start using config file to set up variable names ...
    # aggregate_G = _aggregate_edges(G)
    # aggregate_G = _process_nodes(aggregate_G)

    # TODO: all of this only needs  to happen if graph modified...
    num_nodes = len(preprocessed_G.nodes)
    num_edges = len(preprocessed_G.edges)
    num_components = nx.number_connected_components(preprocessed_G.to_undirected())


    if 'redraw' in kwargs:
        graph_changed = kwargs['redraw'] 

    # json format required by vis.js - this is the data format returned via api to the front-end
    graph_as_json_vis = json_graph.node_link_data(preprocessed_G, {'link': 'edges', 'source': 'from', 'target': 'to'})


    return jsonify({
        'bool_update_status': graph_changed,
        #'str_focal_node_id_list': focal_node_id_list,
        'int_num_nodes': num_nodes,
        'int_num_edges': num_edges,
        'int_num_components': num_components,
        'json_graph': graph_as_json_vis, 
        'network_view_info': network_view_info
    })



# def node_can_explode(node_id, curr_node_list):
#     # check if node can explode (e.g. when double-clicked on)
#     # this is just checking if all the 1-hop exploded nodes are already displayed or not

#     all_graph_data = Graph.getGraph()
#     explodable_node_list = nx.ego_graph(all_graph_data, node_id, radius=1)

#     return not set(explodable_node_list).issubset(set(curr_node_list))

