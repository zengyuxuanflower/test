  app.controller('myController',['$scope', '$http', function($scope, $http) {
  // email = $scope.email;
  // psw = $scope.psw;
  $scope.method = 'my method'; 
  
  $http.get("http://localhost:5000/countries")
                .success(function(response) {
                    $scope.data= response.data;
                });

  $http.get("http://localhost:5000/api/GetNodeList")
                .success(function(response) {
                    $scope.nodelist = response.data;
                });
  // $http({
  //   method: "GET",
  //   url: "http://localhost:5000/api/InduceGraphWithHops?node_id_list=RE-12028789&hops=1",
  //   params: {}

  // }).then(function mySuccess(response) {
  //     // a string, or an object, carrying the response from the server.
  //     $scope.myRes = response.data;
  //     $scope.statuscode = response.status;
  //     console.log($scope.myRes)      

  //   }, function myError(response) {
  //     $scope.myRes = response.statusText;
  //   });
}]);