from flask import Flask
# from marshmallow import Schema, fields, pre_load, validate
# from flask_marshmallow import Marshmallow
# from flask_sqlalchemy import SQLAlchemy
import networkx as nx
from werkzeug.contrib.cache import SimpleCache
import networkx as nx
from networkx.readwrite import json_graph

import json
import pandas as pd


cache = SimpleCache()


# ma = Marshmallow()
# db = SQLAlchemy()
# graph = nx.Graph()


#TODO - create connection to networkx graph - use caching
#TODO - create connection to janusgraph






class Graph():


    def get_graph():

        G = cache.get('trxn_graph')

        if G is None:
            # file = '../../data/entity_trxn_graph.gml'
            # G = nx.read_gml(file)
            file = 'data/trxn_graph_new.graphml'
            G = nx.read_graphml(file)
            cache.set('trxn_graph', G, timeout=5 * 60)
            print('READING GRAPH FROM FILE')

            # find all transaction entity (orig or bene) that have a string match
            # for each entity get the resolved entity id
            # return nodes for that resolved entity


            # print(index_data)
        return G

    def get_index():

        G = Graph.get_graph()

        trxn_index = cache.get('trxn_index')

        if trxn_index is None:

            trxn_index = {}

            # transaction set of individual transactions (unresolved entities)
            for u,v,k,d in G.edges(data=True, keys=True):

                trxn_ref_id = d['trxn_ref_id']

                orig_acct_id = d['orig_acct_id']
                orig_nm = d['orig_nm']
                orig_addr = d['orig_addr']
                
                bene_acct_id = d['bene_acct_id']
                bene_nm = d['bene_nm']
                bene_addr = d['bene_addr']
                

                # for indexing trxns, add both u & v to index value
                if trxn_ref_id not in trxn_index:
                    re_id_list = [u] + [v]
                else:
                    re_id_list = list(set(trxn_index[trxn_ref_id]['re_mapping'] + [u] + [v]))
                trxn_index[trxn_ref_id] = {'type': 'trxn', 're_mapping': re_id_list}


                # check if item in index already, it is append the re_id, else add it
                if orig_acct_id not in trxn_index:
                    re_id_list = [u]
                else:
                    re_id_list = list(set(trxn_index[orig_acct_id]['re_mapping'] + [u]))
                trxn_index[orig_acct_id] = {'type': 'acct', 're_mapping': re_id_list}

                if orig_nm not in trxn_index:
                    re_id_list = [u]
                else:
                    re_id_list = list(set(trxn_index[orig_nm]['re_mapping'] + [u]))
                trxn_index[orig_nm] = {'type': 'name', 're_mapping': re_id_list}

                if orig_addr not in trxn_index:
                    re_id_list = [u]
                else:
                    re_id_list = list(set(trxn_index[orig_addr]['re_mapping'] + [u]))
                trxn_index[orig_addr] = {'type': 'addr', 're_mapping': re_id_list}



                if bene_acct_id not in trxn_index:
                    re_id_list = [v]
                else:
                    re_id_list = list(set(trxn_index[bene_acct_id]['re_mapping'] + [v]))
                trxn_index[bene_acct_id] = {'type': 'acct', 're_mapping': re_id_list}

                if bene_nm not in trxn_index:
                    re_id_list = [v]
                else:
                    re_id_list = list(set(trxn_index[bene_nm]['re_mapping'] + [v]))
                trxn_index[bene_nm] = {'type': 'name', 're_mapping': re_id_list}

                if bene_addr not in trxn_index:
                    re_id_list = [v]
                else:
                    re_id_list = list(set(trxn_index[bene_addr]['re_mapping'] + [v]))
                trxn_index[bene_addr] = {'type': 'addr', 're_mapping': re_id_list}

            cache.set('trxn_index', trxn_index, timeout=5 * 60)

        return trxn_index


    def get_feature_index():

        feature_index = cache.get('feature_index')

        if feature_index is None:
            file = 'data/entity_feature_table.csv.gz'
            feature_table = pd.read_csv(file)
            feature_index = feature_table.set_index('re_id').T.to_dict()

            cache.set('feature_index', feature_index, timeout=5 * 60)
            
        return feature_index




    def get_entity_mapping_index():

        entity_mapping_index = cache.get('entity_mapping_index')

        if entity_mapping_index is None:
            file = '../../../data/entity_mapping_table.csv.gz'
            entity_mapping_index = pd.read_csv(file)
            entity_mapping_index = entity_mapping_index.set_index('re_id').T.to_dict()

            cache.set('entity_mapping_index', entity_mapping_index, timeout=5 * 60)
            
        return entity_mapping_index

