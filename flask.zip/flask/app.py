from flask import Flask, request, jsonify, Blueprint, session

from flask_restful import Api
from flask_cors import CORS

from api.resources.Hello import Hello
from api.resources.Network import *

from utils import *



api_bp = Blueprint('api', __name__)
api = Api(api_bp)

# Route
api.add_resource(NetworkStats, '/api/NetworkStats')
api.add_resource(GetSessionData, '/api/GetSessionData')


api.add_resource(UndoRedo, '/api/UndoRedo')

# graph info getters
api.add_resource(GetNodeList, '/api/GetNodeList')
api.add_resource(GetUREList, '/api/GetUREList')
api.add_resource(SearchEdgeProperties, '/api/SearchEdgeProperties')
api.add_resource(GetNodeListFromSearchItem, '/api/GetNodeListFromSearchItem')

api.add_resource(GetNetworkTrxnList, '/api/GetNetworkTrxnList')


api.add_resource(GetNodeProperties, '/api/GetNodeProperties')
api.add_resource(GetEdgeProperties, '/api/GetEdgeProperties')

# graph actions
api.add_resource(ResetGraph, '/api/ResetGraph')
api.add_resource(InitGraph, '/api/InitGraph')

api.add_resource(InduceGraphWithHops, '/api/InduceGraphWithHops')
api.add_resource(ExpandGraph, '/api/ExpandGraph')
api.add_resource(ContractGraph, '/api/ContractGraph')
api.add_resource(ExplodeNodes, '/api/ExplodeNodes')
api.add_resource(AddNodes, '/api/AddNodes')
api.add_resource(RemoveNodes, '/api/RemoveNodes')
api.add_resource(MergeNodes, '/api/MergeNodes')
api.add_resource(UnmergeNodes, '/api/UnmergeNodes')


api.add_resource(SetDateRange, '/api/SetDateRange')
api.add_resource(SetNodeFix, '/api/SetNodeFix')
api.add_resource(SetViewInfo, '/api/SetViewInfo')

